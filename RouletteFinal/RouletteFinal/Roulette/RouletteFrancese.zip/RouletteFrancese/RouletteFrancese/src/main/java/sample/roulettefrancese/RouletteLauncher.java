package sample.roulettefrancese;

public class RouletteLauncher {
    public static void main(String[] args) {
        RouletteApplication.main(args);
    }
}
