package miniroulette.model.combination;

public enum Combination {
	
	RED, BLACK, EVEN, ODD, UPPER, LOWER, RANDOM;

}
